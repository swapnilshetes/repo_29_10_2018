package com.indecomm.automation;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.indecomm.fixtures.AbstractAutomationFixtures;
import com.indecomm.fixtures.IOSAutomationFixture;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSFindBy;

public class AbstractScenarios {

	AppiumDriver driver;
	AbstractAutomationFixtures abstractAutomationFixtures;
	ElementRepository elementRepository;
	String propetyPath;
	/*
	 * Below xpath will get from common element component file
	 */

		public AbstractScenarios(AppiumDriver driver) {
		System.out.println(":: Start redirecting on login page ::");
		//propetyPath = System.getProperty("user.dir") + "/" + "feedFiles/locator.properties";
		///elementRepository = new ElementRepository(propetyPath);
		//System.out.println(elementRepository.getPropertyByTag("textWithName"));
		//PageFactory.initElements(new AppiumFieldDecorator(driver), this);		
		this.driver = driver;
	}

	public void AppLogin(String platform) throws InterruptedException {

		/*
		 * Click on Continue button to redirect loginpage
		 */
		System.out.println(":: ENTER IN LOGINPAGE ::");
		if(platform.equalsIgnoreCase("iOS"))
		{
			abstractAutomationFixtures=new IOSAutomationFixture(driver);
			
		}
		Thread.sleep(3000);
		driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/X.01I/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup")).click();
		
		driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/X.01I/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup")).sendKeys("ggdfgfd");
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='btnLogin']")).click();
		
		

		//abstractAutomationFixtures.waitForPageToLoad(driver, btnContinue, 10);
		//abstractAutomationFixtures.click(btnContinue);

		// Wait until find Element
		

		/*
		 * On Login page to enter credential
		 */
		Thread.sleep(1000);
		System.out.println(this.driver);
		Thread.sleep(1000);
		System.out.println("*********************");
		System.out.println(this.driver.getPageSource());
		//Thread.sleep(3000);
		System.out.println("*********************");
		
		//btnLogin.click();
		/*System.out.println(txtUserName);
		if(txtUserName.isDisplayed() && txtUserName.isEnabled()) {
			System.out.println("Element display");
			txtUserName.sendKeys("devemerald@electrolux.com");
			txtPassword.sendKeys("Bhasha23@");
		}
		btnLogin.click();*/
		
		//abstractAutomationFixtures.sendText(txtUserName, "devemerald@electrolux.com");
		//abstractAutomationFixtures.sendText(txtPassword, "");
		//abstractAutomationFixtures.click(btnLogin);
	
	}
}
