package com.indecomm.automation;

import io.appium.java_client.AppiumDriver;

public class CommonScenariosIOS extends AbstractScenarios {

	public CommonScenariosIOS(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
