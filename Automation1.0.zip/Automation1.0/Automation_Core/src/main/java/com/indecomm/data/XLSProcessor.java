package com.indecomm.data;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class XLSProcessor implements DataProcessor {

	XSSFWorkbook workbook;
	XSSFSheet xssfSheet;
	Row row;
	public Object getData() 
	{
		return workbook;
	}
	public XSSFSheet getSheet(String name)
    {
    	xssfSheet=workbook.getSheet(name);
    	return xssfSheet;
    }
    public Row getRow(int rowNum)
    {
    	row=xssfSheet.getRow(rowNum);
    	return row;
    }
    public Cell getCell(int cellNo)
    {
    	Cell cell=row.getCell(cellNo);
    	return cell;
    }
	public void processData(String fileName) 
	{
		try
		{
			FileInputStream file = new FileInputStream(new File(fileName)); 
		    // Create Workbook instance holding reference to .xlsx file 
	         workbook = new XSSFWorkbook(file); 
		} catch(Exception exc)
		{
			//Call the log method created in the logger class.
		}
		
	}

}
