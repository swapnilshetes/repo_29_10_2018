package com.indecomm.data;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JSONProcessor implements DataProcessor 
{
    JSONObject jsonObject;
    public JSONProcessor()
    {
    	
    }
	public Object getData() {
		
		return jsonObject;
	}
	public JSONObject getJSONObject(String name)
	{
		JSONObject jObj=(JSONObject)jsonObject.get(name);
		return jObj;
	}
	public String getAttribute(String key)
	{
		String value=(String)jsonObject.get(key);
		return value;
	}
	public String getAttribute(JSONObject json,String key)
	{
		String value=(String)json.get(key);
		return value;
	}
	//Add methods required to get an Array if any.
	public void processData(String fileName) 
	{
		// TODO Auto-generated method stub
		JSONParser jsonParser=null;
		try
		{
			jsonParser=new JSONParser();
			jsonObject=(JSONObject)jsonParser.parse(fileName);
		}catch(Exception exc)
		{
			//Call the logger method to log the exception.
		}
		
		
	}

}
